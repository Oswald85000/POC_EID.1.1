#!/usr/bin/env bash
###############################################################################
# stress_eid.sh — Stress-test complet du micro-service EID-CTRL               #
# ----------------------------------------------------------------------------#
# • Mixe les scénarios pédagogiques (demo_eid_v2.sh)                           #
# • Ajoute un flux « bruit », cadence réglable                                 #
# • Colorise la sortie pour lecture directe dans le terminal                  #
# ----------------------------------------------------------------------------#
# Dépendances : jq, curl, date, awk                                            #
###############################################################################
set -euo pipefail

# ───────────────────────────── Paramètres CLI ────────────────────────────────
API="http://localhost:8000"      # URL micro-service
RATE=20                          # req/s bruit aléatoire
LOOP=0                           # 1 = boucle infinie
while [[ $# -gt 0 ]]; do
  case "$1" in
    -u|--url)   API="$2"; shift 2 ;;
    -r|--rate)  RATE="$2"; shift 2 ;;
    -l|--loop)  LOOP=1; shift ;;
    -h|--help)
      echo "Usage: $0 [--url <addr>] [--rate <req/s>] [--loop]"
      exit 0 ;;
    *) echo "Unknown arg $1" >&2 ; exit 1 ;;
  esac
done

[[ -z $(command -v jq) ]] && { echo "❌ jq n'est pas installé"; exit 1; }

# ────────────────────────── Fonctions utilitaires ────────────────────────────
color() { printf "\033[1;36m%s\033[0m\n" "$*"; }
req()   { curl -s -X POST "$API/$1" -H 'Content-Type: application/json' -d "$2"; }

send_noise() {
  while true; do
    # H,F,O uniformes [0,1[
    read -r H F O < <(awk -vR=$RANDOM 'BEGIN{srand(R);printf "%.3f %.3f %.3f",rand(),rand(),rand()}')
    req update "{\"H\":$H,\"F\":$F,\"O\":$O}" >/dev/null
    sleep "$(awk -v r=$RATE 'BEGIN{printf "%.4f",1/r}')"
  done
}

# ─────────────────────────── Thread bruit de fond ────────────────────────────
color "⚙️  Lancement du générateur de bruit à $RATE req/s …"
send_noise &  NOISE_PID=$!

trap 'kill $NOISE_PID 2>/dev/null' EXIT INT

# ──────────────────────────── Scénarios fixes ────────────────────────────────
run_cycle() {
  color "↻ $(date +%T) — Reset"
  req coeffs '{"alpha":1.2,"beta":1.0,"gamma":0.05,"delta":0}' | jq .

  color "✓ Stable";      req update '{"H":0.35,"F":0.60,"O":0.52}' | jq .
  color "≈ Micro-drift"; req coeffs '{"alpha":1.5,"beta":1.0,"gamma":0.1,"delta":0}' | jq -c .
                         req update '{"H":0.35,"F":0.60,"O":0.52}' | jq .
  color "⚠️  Alarm";     req coeffs '{"alpha":0.5,"beta":1.2,"gamma":0.05,"delta":0}' | jq -c .
                         req update '{"H":0.35,"F":0.90,"O":0.10}' | jq .
  color "‼️ Alarm ++";   req coeffs '{"alpha":0.2,"beta":1.5,"gamma":0.05,"delta":0}' | jq -c .
                         req update '{"H":0.20,"F":1.00,"O":0.00}' | jq .
}

# ────────────────────────── Boucle principale ────────────────────────────────
if [[ $LOOP -eq 1 ]]; then
  while true; do run_cycle; sleep 5; done
else
  run_cycle
fi
