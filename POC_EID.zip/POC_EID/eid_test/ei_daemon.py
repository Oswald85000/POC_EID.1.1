#!/usr/bin/env python3
# ─────────────────────────────────────────────────────────────────────────────
# EID-CTRL micro-service : API REST + exporter Prometheus
# ─────────────────────────────────────────────────────────────────────────────
from flask import Flask, request, jsonify
from prometheus_client import Gauge, generate_latest, REGISTRY, start_http_server
import ctypes
import os

# ───────────────────────── Bibliothèque C chargée dynamiquement ─────────────
lib = ctypes.CDLL(os.path.join(os.path.dirname(__file__), "libeid.so"))
lib.eid_update.restype = ctypes.c_float

class Ctx(ctypes.Structure):
    _fields_ = [("alpha", ctypes.c_float),
                ("beta",  ctypes.c_float),
                ("gamma", ctypes.c_float),
                ("delta", ctypes.c_float)]

# coefficients par défaut (α β γ δ)
ctx = Ctx(1.2, 1.0, 0.05, 0.01)

# ────────────────────────── Métriques Prometheus ─────────────────────────────
g_mu    = Gauge("eid_mu",    "Mu = alpha / beta")
g_dHdt  = Gauge("eid_dHdt",  "Entropic derivative dH/dt")
g_alarm = Gauge("eid_alarm", "Alarm flag (1 if |dHdt|>0 & mu<1)")

# Lancement de l’exporter sur un port dédié (9000 par défaut)
PROM_PORT = int(os.getenv("EID_PROM_PORT", "9000"))
start_http_server(PROM_PORT)

# ───────────────────────────── API Flask ─────────────────────────────────────
app = Flask(__name__)

@app.route("/update", methods=["POST"])
def update():
    """Calcul dH/dt à partir de H F O et mise à jour des métriques."""
    data = request.get_json(force=True, silent=True) or {}
    H = float(data.get("H", 1.0))
    F = float(data.get("F", 0.1))
    O = float(data.get("O", 0.0))

    alarm = ctypes.c_bool()
    dHdt = lib.eid_update(ctypes.byref(ctx),
                          ctypes.c_float(H), ctypes.c_float(F), ctypes.c_float(O),
                          ctypes.byref(alarm))
    mu = ctx.alpha / ctx.beta

    g_mu.set(mu)
    g_dHdt.set(dHdt)
    g_alarm.set(int(alarm.value))

    return jsonify(dHdt=dHdt, mu=mu, alarm=bool(alarm.value))

@app.route("/coeffs", methods=["POST"])
def set_coeffs():
    """Modification à chaud des coefficients α β γ δ."""
    data = request.get_json(force=True, silent=True) or {}
    ctx.alpha = float(data.get("alpha", ctx.alpha))
    ctx.beta  = float(data.get("beta",  ctx.beta))
    ctx.gamma = float(data.get("gamma", ctx.gamma))
    ctx.delta = float(data.get("delta", ctx.delta))

    return jsonify(alpha=ctx.alpha, beta=ctx.beta,
                   gamma=ctx.gamma, delta=ctx.delta)

@app.route("/metrics")
def metrics():
    """Point de collecte Prometheus (exposé aussi sur 8000 pour debug)."""
    return generate_latest(REGISTRY), 200, {"Content-Type": "text/plain"}

# ──────────────────────────── Lancement serveur ──────────────────────────────
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
