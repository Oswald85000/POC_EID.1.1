#!/usr/bin/env python3
# feed_random.py – TRNG → EID, H/F normalisés 0‥1
import os, time, math, requests

API    = "http://localhost:8000/update"
BLK    = 256      # octets
PERIOD = 0.2      # 200 ms (5 Hz)

def shannon(bits: bytes) -> float:
    hist = [0]*256
    for b in bits: hist[b] += 1
    H = 0.0
    for c in hist:
        if c:
            p = c/BLK
            H -= p*math.log2(p)
    return H / (BLK*8)                # → 0‥1

def ones_ratio(bits: bytes) -> float:
    ones = sum(bin(b).count("1") for b in bits)
    return (ones/(BLK*8) - .5)*2       # –1‥1, 0 = parfait équilibre

while True:
    buf = os.urandom(BLK)
    payload = {"H": shannon(buf), "F": ones_ratio(buf), "O": 0}
    try:
        print(requests.post(API, json=payload, timeout=1).json())
    except requests.exceptions.RequestException as e:
        print("✘", e)
    time.sleep(PERIOD)
